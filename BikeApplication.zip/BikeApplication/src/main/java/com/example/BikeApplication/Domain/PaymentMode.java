package com.example.BikeApplication.Domain;

public enum PaymentMode {
    CASH_ON_DELIVERY,
    CREDIT_CARD,
    DEBIT_CARD,
    UPI_PAYMENT,
    NET_BANKING
}
